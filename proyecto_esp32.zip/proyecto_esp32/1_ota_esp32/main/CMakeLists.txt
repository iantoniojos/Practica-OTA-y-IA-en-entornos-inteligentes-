# El certificado se incrusta como texto (terminado en NUL) en el binario.
# Genera el símbolo _binary_server_crt_start usado en main.c
idf_component_register(SRCS "main.c"
                       INCLUDE_DIRS "."
                       EMBED_TXTFILES "server.crt")
