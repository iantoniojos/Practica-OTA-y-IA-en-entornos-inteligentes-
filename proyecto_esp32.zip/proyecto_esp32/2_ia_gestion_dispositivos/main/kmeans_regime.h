/**
 * @file kmeans_regime.h
 * @brief Clasificación del régimen ambiental con K-Means (centroides pre-entrenados).
 *
 * Asigna cada lectura [T, RH] al clúster más cercano para responder:
 * ¿en qué "modo" de operación está el entorno ahora mismo?
 *
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#ifndef KMEANS_REGIME_H
#define KMEANS_REGIME_H

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Número de grupos/estados a identificar. */
#define K_CLUSTERS 3
/** @brief Variables por muestra: [0] temperatura, [1] humedad. */
#define NUM_FEATURES 2

/** @brief Temperatura mínima esperada para el escalado Min-Max (°C). */
#define TEMP_MIN 0.0f
/** @brief Temperatura máxima esperada para el escalado Min-Max (°C). */
#define TEMP_MAX 50.0f
/** @brief Humedad mínima para el escalado Min-Max (%). */
#define HUM_MIN  0.0f
/** @brief Humedad máxima para el escalado Min-Max (%). */
#define HUM_MAX  100.0f

/**
 * @brief Distancia al centroide (espacio normalizado) a partir de la cual
 *        una lectura se considera inusualmente lejos de su clúster.
 */
#define KMEANS_FAR_DISTANCE 0.25f

/** @brief Resultado de la inferencia K-Means. */
typedef struct {
    int cluster_id;            /**< ID del clúster asignado (-1 si no hay). */
    const char *cluster_label; /**< Etiqueta legible del clúster. */
    float min_distance;        /**< Distancia euclidiana real al centroide. */
} kmeans_result_t;

/**
 * @brief Clasifica una muestra en el clúster más cercano.
 * @param[in] temp Temperatura en °C.
 * @param[in] humidity Humedad relativa en %.
 * @return Clúster asignado y distancia al centroide.
 */
kmeans_result_t kmeans_predict(float temp, float humidity);

#ifdef __cplusplus
}
#endif

#endif /* KMEANS_REGIME_H */
