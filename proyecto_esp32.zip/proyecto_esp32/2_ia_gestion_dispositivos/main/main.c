/**
 * @file main.c
 * @brief Monitor ambiental con TinyML en el ESP32: gestión inteligente del dispositivo.
 *
 * El nodo mide temperatura y humedad con un SHT31 y genera localmente, sin
 * depender de la nube, los siguientes insights:
 *  - **Health Check** del sensor (comunicación, rango, saltos bruscos).
 *  - **Cálculos físicos**: punto de rocío y VPD (ver env_insights.h).
 *  - **Detección de anomalías** con distancia L2 sobre Z-Score (env_insights.h),
 *    equivalente ultraligero de un Isolation Forest para T y RH.
 *  - **Régimen ambiental** con K-Means (kmeans_regime.h).
 *
 * @section registro Compresión inteligente de registros (MicroSD)
 * | Situación                                   | Periodo de lectura | Se escribe en la SD               |
 * |---------------------------------------------|--------------------|-----------------------------------|
 * | Variables estables                          | ::SENSE_PERIOD_NORMAL_S | Cada ::LOG_PERIOD_NORMAL_S (10 min) |
 * | Anomalía local                              | ::SENSE_PERIOD_ALERT_S  | Cada lectura, evento "ANOMALIA"   |
 * | Cambio de clúster / distancia inusual alta  | normal             | Inmediatamente, con el evento     |
 * | Falla del sensor                            | ::SENSE_PERIOD_ALERT_S  | Evento "SENSOR_FALLA"             |
 *
 * @note Con ::SIMULATE_SENSOR en 1 se usan lecturas simuladas (sin hardware).
 *
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */

#include <stdio.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"

#include "sht31.h"
#include "env_insights.h"
#include "kmeans_regime.h"
#include "sd_logger.h"

/** @brief 1 = usa lecturas simuladas (útil sin sensor); 0 = lee el SHT31 real. */
#define SIMULATE_SENSOR 0
/** @brief Periodo de lectura con el ambiente estable (s). */
#define SENSE_PERIOD_NORMAL_S 30
/** @brief Periodo de lectura ante anomalía o falla del sensor (s). */
#define SENSE_PERIOD_ALERT_S  5
/** @brief Periodo de registro en la SD cuando todo es estable (s): 10 minutos. */
#define LOG_PERIOD_NORMAL_S   600

/** @brief Etiqueta de log. */
static const char *TAG = "TINYML_MONITOR";

#if SIMULATE_SENSOR
/** @brief Temperaturas simuladas (°C). */
static const float SIM_T[]  = {24.5f, 25.1f, 38.5f, 22.0f, 16.2f, 37.5f};
/** @brief Humedades simuladas (%). */
static const float SIM_RH[] = {58.0f, 62.0f, 95.0f, 15.0f, 72.0f, 88.0f};
#endif

/**
 * @brief Obtiene una lectura del sensor (real o simulada).
 * @param[out] t Temperatura en °C.
 * @param[out] rh Humedad relativa en %.
 * @return ESP_OK si la lectura es válida.
 */
static esp_err_t read_sensor(float *t, float *rh)
{
#if SIMULATE_SENSOR
    static size_t i = 0;
    *t = SIM_T[i];
    *rh = SIM_RH[i];
    i = (i + 1) % (sizeof(SIM_T) / sizeof(SIM_T[0]));
    return ESP_OK;
#else
    return sht31_read(t, rh);
#endif
}

/**
 * @brief Tarea de monitoreo: lee, analiza, decide si registrar y ajusta su ritmo.
 * @param[in] arg No se usa.
 */
static void monitor_task(void *arg)
{
    int last_cluster = -1;
    int64_t last_log_us = 0;
    bool first = true;

    while (true) {
        float t = NAN, rh = NAN;
        esp_err_t err = read_sensor(&t, &rh);
        sht31_health_t health = sht31_check_health(err, t, rh);
        uint32_t period_s = SENSE_PERIOD_NORMAL_S;
        int64_t now_us = esp_timer_get_time();

        log_record_t rec = {0};
        rec.health = health;
        rec.event = NULL;

        if (health == SHT31_HEALTH_COMM_FAIL || health == SHT31_HEALTH_OUT_OF_RANGE) {
            /* Sensor no confiable: se marca el evento y se acelera el reintento */
            ESP_LOGE(TAG, "Salud del sensor: %s", sht31_health_str(health));
            rec.insights.temp_c = t;
            rec.insights.humidity_pct = rh;
            rec.regime.cluster_id = -1;
            rec.event = "SENSOR_FALLA";
            period_s = SENSE_PERIOD_ALERT_S;
        } else if (err == ESP_OK) {
            rec.insights = process_sensor_data(t, rh);
            rec.regime = kmeans_predict(t, rh);

            ESP_LOGI(TAG, "T: %.2f C | RH: %.2f %% | Rocio: %.2f C | VPD: %.2f kPa",
                     t, rh, rec.insights.dew_point_c, rec.insights.vpd_kpa);
            ESP_LOGI(TAG, "Score: %.2f (%s) | Cluster %d [%s] dist %.3f | Salud: %s",
                     rec.insights.anomaly_score,
                     rec.insights.is_anomaly ? "ANOMALIA" : "normal",
                     rec.regime.cluster_id, rec.regime.cluster_label,
                     rec.regime.min_distance, sht31_health_str(health));

            if (rec.insights.is_anomaly) {
                rec.event = "ANOMALIA";
                period_s = SENSE_PERIOD_ALERT_S;
                ESP_LOGW(TAG, "Evento atipico: se aumenta la tasa de muestreo y se marca en la SD");
            } else if (health == SHT31_HEALTH_JUMP) {
                rec.event = "SALTO_BRUSCO";
            } else if (last_cluster >= 0 && rec.regime.cluster_id != last_cluster) {
                rec.event = "CAMBIO_CLUSTER";
            } else if (rec.regime.min_distance > KMEANS_FAR_DISTANCE) {
                rec.event = "DISTANCIA_ALTA";
            } else if (first || (now_us - last_log_us) >= (int64_t)LOG_PERIOD_NORMAL_S * 1000000) {
                rec.event = "PERIODICO";
            }
            last_cluster = rec.regime.cluster_id;
            first = false;
        } else {
            ESP_LOGW(TAG, "Lectura fallida (%s), se reintenta", esp_err_to_name(err));
            period_s = SENSE_PERIOD_ALERT_S;
        }

        if (rec.event != NULL) {
            if (sd_logger_write(&rec) == ESP_OK) {
                last_log_us = now_us;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(period_s * 1000));
    }
}

/**
 * @brief Punto de entrada: inicializa sensor y MicroSD, y lanza la tarea de monitoreo.
 */
void app_main(void)
{
    ESP_LOGI(TAG, "Iniciando sistema de inferencia TinyML para SHT31...");

#if !SIMULATE_SENSOR
    if (sht31_init() != ESP_OK) {
        ESP_LOGE(TAG, "No se pudo inicializar el SHT31 (SDA=%d, SCL=%d)",
                 SHT31_SDA_GPIO, SHT31_SCL_GPIO);
        return;
    }
#endif

    if (sd_logger_init() != ESP_OK) {
        ESP_LOGE(TAG, "Sin MicroSD: no se podran guardar registros");
        return;
    }

    xTaskCreate(monitor_task, "monitor", 6144, NULL, 5, NULL);
}
