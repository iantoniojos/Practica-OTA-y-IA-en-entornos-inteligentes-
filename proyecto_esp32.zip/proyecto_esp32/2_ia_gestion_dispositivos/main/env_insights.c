/**
 * @file env_insights.c
 * @brief Implementación de los cálculos físicos y del detector de anomalías.
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#include <math.h>
#include "env_insights.h"

/**
 * @brief Calcula el Punto de Rocío (Dew Point) en °C con la fórmula de Magnus.
 * @param[in] temp Temperatura en °C.
 * @param[in] rh Humedad relativa en % (se limita a un mínimo de 1 % para evitar log(0)).
 * @return Punto de rocío en °C.
 */
static float calculate_dew_point(float temp, float rh)
{
    const float a = 17.27f;
    const float b = 237.7f;
    if (rh < 1.0f) rh = 1.0f;
    float alpha = ((a * temp) / (b + temp)) + logf(rh / 100.0f);
    return (b * alpha) / (a - alpha);
}

/**
 * @brief Calcula el Déficit de Presión de Vapor (VPD) en kPa.
 * @param[in] temp Temperatura en °C.
 * @param[in] rh Humedad relativa en %.
 * @return VPD en kPa (presión de saturación menos presión actual de vapor).
 */
static float calculate_vpd(float temp, float rh)
{
    float svp = 0.61078f * expf((17.27f * temp) / (temp + 237.3f));
    float avp = svp * (rh / 100.0f);
    return svp - avp;
}

/**
 * @brief Calcula el score de anomalía como distancia L2 en el espacio Z-Score.
 *
 * Es un equivalente simplificado de la distancia de Mahalanobis (sin
 * covarianza) y ultraligero en RAM/Flash.
 *
 * @param[in] temp Temperatura en °C.
 * @param[in] rh Humedad relativa en %.
 * @return Score de anomalía (adimensional).
 */
static float calculate_anomaly_score(float temp, float rh)
{
    float z_temp = (temp - TRAIN_TEMP_MEAN) / TRAIN_TEMP_STD;
    float z_hum  = (rh - TRAIN_HUM_MEAN) / TRAIN_HUM_STD;
    return sqrtf((z_temp * z_temp) + (z_hum * z_hum));
}

sensor_insights_t process_sensor_data(float temp_c, float humidity_pct)
{
    sensor_insights_t insights;

    insights.temp_c = temp_c;
    insights.humidity_pct = humidity_pct;
    insights.dew_point_c = calculate_dew_point(temp_c, humidity_pct);
    insights.vpd_kpa = calculate_vpd(temp_c, humidity_pct);
    insights.anomaly_score = calculate_anomaly_score(temp_c, humidity_pct);
    insights.is_anomaly = (insights.anomaly_score > ANOMALY_THRESHOLD);

    return insights;
}
