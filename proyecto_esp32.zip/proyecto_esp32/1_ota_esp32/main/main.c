/**
 * @file main.c
 * @brief Cliente OTA (Over-The-Air) para ESP32 con ESP-IDF vía HTTPS.
 *
 * El ESP32 se conecta a la red Wi-Fi, descarga el firmware nuevo
 * (@c firmware_v2.bin) desde un servidor HTTPS local escrito en Python
 * (ver @ref server_ota.py) y lo escribe en la partición OTA inactiva.
 * Al terminar con éxito, reinicia y arranca desde la nueva partición.
 *
 * @section arquitectura Arquitectura de memoria
 * La flash se divide en dos ranuras simétricas (@c ota_0 y @c ota_1) y una
 * partición @c otadata que guarda cuál ranura debe arrancar (ver partitions.csv).
 *
 * @section uso Uso
 * 1. Generar @c server.crt / @c server.key y copiar @c server.crt a @c main/.
 * 2. Ajustar @ref OTA_URL con la IP del PC.
 * 3. Configurar SSID y clave en @c idf.py menuconfig (Example Connection Configuration).
 * 4. Flashear v1.0.0 por USB; compilar v2.0.0 y copiar el .bin al servidor.
 *
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_ota_ops.h"
#include "esp_https_ota.h"
#include "protocol_examples_common.h"

/** @brief Etiqueta usada en los mensajes de log. */
static const char *TAG = "ESP32_OTA";

/** @brief Inicio del certificado del servidor, incrustado desde main/CMakeLists.txt. */
extern const uint8_t server_cert_pem_start[] asm("_binary_server_crt_start");

/**
 * @brief URL del firmware nuevo.
 * @note Reemplace 192.168.1.50 por la IP del PC que ejecuta server_ota.py.
 *       Debe coincidir con la IP (subjectAltName) del certificado.
 */
#define OTA_URL "https://192.168.1.50:8070/firmware_v2.bin"

/** @brief Tiempo máximo de espera de la conexión HTTPS, en milisegundos. */
#define OTA_TIMEOUT_MS 10000

/**
 * @brief Muestra la partición y la versión del firmware que se está ejecutando.
 *
 * Útil para comprobar visualmente que, tras el reinicio, el ESP32 arrancó
 * desde la ranura nueva (ota_1) con la versión esperada.
 */
static void log_running_firmware(void)
{
    const esp_partition_t *running = esp_ota_get_running_partition();
    esp_app_desc_t info;

    if (esp_ota_get_partition_description(running, &info) == ESP_OK) {
        ESP_LOGI(TAG, "Ejecutando '%s' versión %s desde la partición '%s'",
                 info.project_name, info.version, running->label);
    }
}

/**
 * @brief Tarea FreeRTOS que realiza la actualización OTA.
 *
 * Descarga el binario con la API de alto nivel @c esp_https_ota(), que
 * valida la imagen, la escribe en la partición inactiva y actualiza
 * @c otadata. Si todo sale bien reinicia el equipo; si falla, informa el
 * código de error y el firmware actual sigue funcionando.
 *
 * @param[in] pvParameter No se usa.
 */
static void ota_task(void *pvParameter)
{
    ESP_LOGI(TAG, "Iniciando descarga OTA desde %s", OTA_URL);

    esp_http_client_config_t http_config = {
        .url        = OTA_URL,
        .cert_pem   = (const char *)server_cert_pem_start,
        .timeout_ms = OTA_TIMEOUT_MS,
    };
    esp_https_ota_config_t ota_config = {
        .http_config = &http_config,
    };

    esp_err_t ret = esp_https_ota(&ota_config);
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "Actualización exitosa. Reiniciando...");
        vTaskDelay(pdMS_TO_TICKS(1000));
        esp_restart();
    } else {
        ESP_LOGE(TAG, "Fallo en la actualización OTA: %s (0x%x)",
                 esp_err_to_name(ret), ret);
    }
    vTaskDelete(NULL);
}

/**
 * @brief Punto de entrada de la aplicación.
 *
 * Inicializa NVS, la pila de red y el bucle de eventos, se conecta al Wi-Fi
 * y lanza la tarea de actualización OTA.
 */
void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    log_running_firmware();

    ESP_ERROR_CHECK(example_connect()); /* Conexión Wi-Fi (menuconfig) */

    xTaskCreate(&ota_task, "ota_task", 8192, NULL, 5, NULL);
}
