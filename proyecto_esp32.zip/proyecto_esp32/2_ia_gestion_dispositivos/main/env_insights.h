/**
 * @file env_insights.h
 * @brief Insights locales: punto de rocío, VPD y detección de anomalías (L2 sobre Z-Score).
 *
 * Es el equivalente ultraligero de un Isolation Forest para pocas variables
 * (T y RH): mide qué tan lejos está la lectura actual del comportamiento
 * "normal" de entrenamiento, usando la distancia euclidiana (L2) sobre
 * variables estandarizadas.
 *
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#ifndef ENV_INSIGHTS_H
#define ENV_INSIGHTS_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Media de temperatura del baseline de entrenamiento (°C). */
#define TRAIN_TEMP_MEAN 25.0f
/** @brief Desviación estándar de temperatura del baseline (°C). */
#define TRAIN_TEMP_STD  5.0f
/** @brief Media de humedad relativa del baseline (%). */
#define TRAIN_HUM_MEAN  60.0f
/** @brief Desviación estándar de humedad del baseline (%). */
#define TRAIN_HUM_STD   15.0f
/** @brief Umbral del score por encima del cual la lectura es atípica. */
#define ANOMALY_THRESHOLD 2.5f

/** @brief Datos procesados e insights de una lectura. */
typedef struct {
    float temp_c;         /**< Temperatura medida (°C). */
    float humidity_pct;   /**< Humedad relativa medida (%). */
    float dew_point_c;    /**< Punto de rocío (°C), fórmula de Magnus. */
    float vpd_kpa;        /**< Déficit de presión de vapor (kPa). */
    float anomaly_score;  /**< Distancia L2 en el espacio Z-Score. */
    bool  is_anomaly;     /**< true si el score supera ::ANOMALY_THRESHOLD. */
} sensor_insights_t;

/**
 * @brief Procesa una lectura y calcula todos los insights locales.
 * @param[in] temp_c Temperatura en °C.
 * @param[in] humidity_pct Humedad relativa en %.
 * @return Estructura con punto de rocío, VPD, score y bandera de anomalía.
 */
sensor_insights_t process_sensor_data(float temp_c, float humidity_pct);

#ifdef __cplusplus
}
#endif

#endif /* ENV_INSIGHTS_H */
