/**
 * @file sd_logger.h
 * @brief Registro de datos e insights en una MicroSD (SPI) en formato CSV.
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#ifndef SD_LOGGER_H
#define SD_LOGGER_H

#include "esp_err.h"
#include "env_insights.h"
#include "kmeans_regime.h"
#include "sht31.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief GPIO MOSI del módulo MicroSD. */
#define SD_PIN_MOSI 23
/** @brief GPIO MISO del módulo MicroSD. */
#define SD_PIN_MISO 19
/** @brief GPIO SCLK del módulo MicroSD. */
#define SD_PIN_CLK  18
/** @brief GPIO CS del módulo MicroSD. */
#define SD_PIN_CS   5

/** @brief Registro que se escribe en cada fila del CSV. */
typedef struct {
    sensor_insights_t insights; /**< Lectura, punto de rocío, VPD y score. */
    kmeans_result_t   regime;   /**< Clúster asignado y distancia. */
    sht31_health_t    health;   /**< Estado de salud del sensor. */
    const char       *event;    /**< Motivo del registro (PERIODICO, ANOMALIA, ...). */
} log_record_t;

/**
 * @brief Monta la MicroSD en /sdcard.
 * @return ESP_OK si la tarjeta se montó correctamente.
 */
esp_err_t sd_logger_init(void);

/**
 * @brief Agrega una fila al archivo /sdcard/datos.csv (crea el encabezado si no existe).
 * @param[in] rec Registro a escribir.
 * @return ESP_OK si se escribió correctamente.
 */
esp_err_t sd_logger_write(const log_record_t *rec);

#ifdef __cplusplus
}
#endif

#endif /* SD_LOGGER_H */
