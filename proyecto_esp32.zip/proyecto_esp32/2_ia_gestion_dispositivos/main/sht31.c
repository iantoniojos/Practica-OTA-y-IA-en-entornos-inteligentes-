/**
 * @file sht31.c
 * @brief Implementación del driver SHT31 con la API i2c_master de ESP-IDF (>= 5.2).
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#include <string.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c_master.h"
#include "sht31.h"

/** @brief Dirección I2C de 7 bits del SHT31 (ADDR a GND). */
#define SHT31_ADDR            0x44
/** @brief Tiempo máximo de transacción I2C, en ms. */
#define I2C_TIMEOUT_MS        100
/** @brief Fallas consecutivas para declarar falla de comunicación. */
#define MAX_COMM_FAILS        3
/** @brief Salto máximo de temperatura entre lecturas (°C) antes de marcarlo sospechoso. */
#define MAX_TEMP_JUMP_C       8.0f
/** @brief Salto máximo de humedad entre lecturas (%) antes de marcarlo sospechoso. */
#define MAX_HUM_JUMP_PCT      30.0f

/** @brief Manejador del dispositivo I2C. */
static i2c_master_dev_handle_t s_dev;
/** @brief Contador de fallas de comunicación consecutivas. */
static int s_fail_count = 0;
/** @brief Última lectura válida de temperatura. */
static float s_last_t = NAN;
/** @brief Última lectura válida de humedad. */
static float s_last_rh = NAN;

/**
 * @brief Calcula el CRC-8 del SHT31 (polinomio 0x31, valor inicial 0xFF).
 * @param[in] data Bytes a verificar.
 * @param[in] len Cantidad de bytes.
 * @return CRC calculado.
 */
static uint8_t crc8(const uint8_t *data, int len)
{
    uint8_t crc = 0xFF;
    for (int i = 0; i < len; i++) {
        crc ^= data[i];
        for (int b = 0; b < 8; b++) {
            crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0x31) : (uint8_t)(crc << 1);
        }
    }
    return crc;
}

esp_err_t sht31_init(void)
{
    i2c_master_bus_config_t bus_cfg;
    memset(&bus_cfg, 0, sizeof(bus_cfg));
    bus_cfg.i2c_port = I2C_NUM_0;
    bus_cfg.sda_io_num = (gpio_num_t)SHT31_SDA_GPIO;
    bus_cfg.scl_io_num = (gpio_num_t)SHT31_SCL_GPIO;
    bus_cfg.clk_source = I2C_CLK_SRC_DEFAULT;
    bus_cfg.glitch_ignore_cnt = 7;
    bus_cfg.flags.enable_internal_pullup = true;

    i2c_master_bus_handle_t bus;
    esp_err_t err = i2c_new_master_bus(&bus_cfg, &bus);
    if (err != ESP_OK) return err;

    i2c_device_config_t dev_cfg;
    memset(&dev_cfg, 0, sizeof(dev_cfg));
    dev_cfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    dev_cfg.device_address = SHT31_ADDR;
    dev_cfg.scl_speed_hz = 100000;

    return i2c_master_bus_add_device(bus, &dev_cfg, &s_dev);
}

esp_err_t sht31_read(float *temp_c, float *rh_pct)
{
    /* Comando 0x2400: disparo único, alta repetibilidad, sin clock stretching */
    const uint8_t cmd[2] = { 0x24, 0x00 };
    uint8_t raw[6];

    esp_err_t err = i2c_master_transmit(s_dev, cmd, sizeof(cmd), I2C_TIMEOUT_MS);
    if (err != ESP_OK) return err;

    vTaskDelay(pdMS_TO_TICKS(20)); /* Tiempo de medición (~15 ms) */

    err = i2c_master_receive(s_dev, raw, sizeof(raw), I2C_TIMEOUT_MS);
    if (err != ESP_OK) return err;

    if (crc8(raw, 2) != raw[2] || crc8(raw + 3, 2) != raw[5]) {
        return ESP_ERR_INVALID_CRC;
    }

    uint16_t t_raw = (uint16_t)((raw[0] << 8) | raw[1]);
    uint16_t h_raw = (uint16_t)((raw[3] << 8) | raw[4]);
    *temp_c = -45.0f + 175.0f * ((float)t_raw / 65535.0f);
    *rh_pct = 100.0f * ((float)h_raw / 65535.0f);
    return ESP_OK;
}

sht31_health_t sht31_check_health(esp_err_t err, float temp_c, float rh_pct)
{
    if (err != ESP_OK) {
        s_fail_count++;
        return (s_fail_count >= MAX_COMM_FAILS) ? SHT31_HEALTH_COMM_FAIL : SHT31_HEALTH_OK;
    }
    s_fail_count = 0;

    if (temp_c < -40.0f || temp_c > 125.0f || rh_pct < 0.0f || rh_pct > 100.0f) {
        return SHT31_HEALTH_OUT_OF_RANGE;
    }

    sht31_health_t result = SHT31_HEALTH_OK;
    if (!isnan(s_last_t) &&
        (fabsf(temp_c - s_last_t) > MAX_TEMP_JUMP_C ||
         fabsf(rh_pct - s_last_rh) > MAX_HUM_JUMP_PCT)) {
        result = SHT31_HEALTH_JUMP;
    }
    s_last_t = temp_c;
    s_last_rh = rh_pct;
    return result;
}

const char *sht31_health_str(sht31_health_t h)
{
    switch (h) {
    case SHT31_HEALTH_OK:           return "OK";
    case SHT31_HEALTH_COMM_FAIL:    return "FALLA_COMUNICACION";
    case SHT31_HEALTH_OUT_OF_RANGE: return "FUERA_DE_RANGO";
    case SHT31_HEALTH_JUMP:         return "SALTO_BRUSCO";
    default:                        return "DESCONOCIDO";
    }
}
