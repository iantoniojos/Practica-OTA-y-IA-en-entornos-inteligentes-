/**
 * @file sht31.h
 * @brief Driver del sensor de temperatura y humedad SHT31 (I2C) con verificación de salud.
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#ifndef SHT31_H
#define SHT31_H

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Pin SDA del bus I2C. */
#define SHT31_SDA_GPIO 21
/** @brief Pin SCL del bus I2C. */
#define SHT31_SCL_GPIO 22

/** @brief Resultado del chequeo de salud del sensor (Health Check). */
typedef enum {
    SHT31_HEALTH_OK = 0,        /**< Sensor respondiendo con normalidad. */
    SHT31_HEALTH_COMM_FAIL,     /**< Fallas de I2C o de CRC consecutivas. */
    SHT31_HEALTH_OUT_OF_RANGE,  /**< Lectura fuera del rango físico del sensor. */
    SHT31_HEALTH_JUMP           /**< Salto brusco entre lecturas (posible drift o falla). */
} sht31_health_t;

/**
 * @brief Inicializa el bus I2C y registra el SHT31 (dirección 0x44).
 * @return ESP_OK si se creó el bus y el dispositivo.
 */
esp_err_t sht31_init(void);

/**
 * @brief Realiza una medición de disparo único (alta repetibilidad).
 * @param[out] temp_c Temperatura en °C.
 * @param[out] rh_pct Humedad relativa en %.
 * @return ESP_OK, ESP_ERR_INVALID_CRC si falló el CRC, u otro error de I2C.
 */
esp_err_t sht31_read(float *temp_c, float *rh_pct);

/**
 * @brief Evalúa la salud del sensor con la última lectura.
 *
 * Detecta: fallas de comunicación consecutivas, valores fuera de rango
 * (T: -40 a 125 °C, RH: 0 a 100 %) y saltos bruscos entre lecturas.
 *
 * @param[in] err Resultado de sht31_read().
 * @param[in] temp_c Temperatura leída.
 * @param[in] rh_pct Humedad leída.
 * @return Estado de salud ::sht31_health_t.
 */
sht31_health_t sht31_check_health(esp_err_t err, float temp_c, float rh_pct);

/**
 * @brief Convierte el estado de salud a texto.
 * @param[in] h Estado de salud.
 * @return Cadena constante descriptiva.
 */
const char *sht31_health_str(sht31_health_t h);

#ifdef __cplusplus
}
#endif

#endif /* SHT31_H */
