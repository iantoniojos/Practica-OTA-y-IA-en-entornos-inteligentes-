/**
 * @file sd_logger.c
 * @brief Implementación del registrador CSV sobre MicroSD (SPI + FAT).
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#include <stdio.h>
#include <sys/stat.h>
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include "driver/sdspi_host.h"
#include "driver/spi_common.h"
#include "sd_logger.h"

/** @brief Etiqueta de log. */
static const char *TAG = "SD_LOGGER";
/** @brief Punto de montaje de la MicroSD. */
#define MOUNT_POINT "/sdcard"
/** @brief Ruta del archivo CSV. */
#define LOG_FILE MOUNT_POINT "/datos.csv"

esp_err_t sd_logger_init(void)
{
    esp_vfs_fat_sdmmc_mount_config_t mount_cfg = {
        .format_if_mount_failed = false,
        .max_files = 4,
        .allocation_unit_size = 16 * 1024,
    };

    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = SPI2_HOST;

    spi_bus_config_t bus_cfg = {
        .mosi_io_num = SD_PIN_MOSI,
        .miso_io_num = SD_PIN_MISO,
        .sclk_io_num = SD_PIN_CLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 4000,
    };
    esp_err_t err = spi_bus_initialize(host.slot, &bus_cfg, SDSPI_DEFAULT_DMA);
    if (err != ESP_OK) return err;

    sdspi_device_config_t slot_cfg = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_cfg.gpio_cs = SD_PIN_CS;
    slot_cfg.host_id = host.slot;

    sdmmc_card_t *card;
    err = esp_vfs_fat_sdspi_mount(MOUNT_POINT, &host, &slot_cfg, &mount_cfg, &card);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "No se pudo montar la MicroSD (%s)", esp_err_to_name(err));
        return err;
    }
    sdmmc_card_print_info(stdout, card);
    return ESP_OK;
}

esp_err_t sd_logger_write(const log_record_t *rec)
{
    struct stat st;
    bool is_new = (stat(LOG_FILE, &st) != 0);

    FILE *f = fopen(LOG_FILE, "a");
    if (f == NULL) {
        ESP_LOGE(TAG, "No se pudo abrir %s", LOG_FILE);
        return ESP_FAIL;
    }

    if (is_new) {
        fprintf(f, "uptime_s,temp_c,rh_pct,dew_point_c,vpd_kpa,anomaly_score,"
                   "anomalia,cluster_id,cluster_dist,salud_sensor,evento\n");
    }

    fprintf(f, "%lld,%.2f,%.2f,%.2f,%.3f,%.2f,%d,%d,%.4f,%s,%s\n",
            (long long)(esp_timer_get_time() / 1000000),
            rec->insights.temp_c, rec->insights.humidity_pct,
            rec->insights.dew_point_c, rec->insights.vpd_kpa,
            rec->insights.anomaly_score, rec->insights.is_anomaly ? 1 : 0,
            rec->regime.cluster_id, rec->regime.min_distance,
            sht31_health_str(rec->health), rec->event);

    fclose(f);
    return ESP_OK;
}
