/**
 * @file kmeans_regime.c
 * @brief Implementación de la inferencia K-Means con centroides fijos.
 * @author Antonio José Lizcano Rojas
 * @date 2026
 */
#include <math.h>
#include "kmeans_regime.h"

/** @brief Definición de un clúster pre-entrenado. */
typedef struct {
    int id;                        /**< Identificador del clúster. */
    const char *label;             /**< Etiqueta del régimen. */
    float centroid[NUM_FEATURES];  /**< Centroide [Temp, RH] normalizado a [0, 1]. */
} cluster_t;

/**
 * @brief Centroides obtenidos offline (Python o Edge Impulse), en espacio normalizado.
 */
static const cluster_t clusters[K_CLUSTERS] = {
    { .id = 0, .label = "Ambiente Fresco / Nocturno",          .centroid = {0.30f, 0.70f} }, /* ~15 C, 70 %RH */
    { .id = 1, .label = "Operacion Confort / Normal",          .centroid = {0.48f, 0.50f} }, /* ~24 C, 50 %RH */
    { .id = 2, .label = "Alta Temp / Alerta Condensacion",     .centroid = {0.76f, 0.85f} }, /* ~38 C, 85 %RH */
};

/**
 * @brief Escala un valor al rango [0, 1] (normalización Min-Max, saturando).
 * @param[in] val Valor a escalar.
 * @param[in] min Mínimo del rango.
 * @param[in] max Máximo del rango.
 * @return Valor normalizado.
 */
static inline float normalize(float val, float min, float max)
{
    if (val < min) return 0.0f;
    if (val > max) return 1.0f;
    return (val - min) / (max - min);
}

kmeans_result_t kmeans_predict(float temp, float humidity)
{
    kmeans_result_t result = {
        .cluster_id = -1,
        .cluster_label = "Desconocido",
        .min_distance = 1e9f
    };

    float feat[NUM_FEATURES];
    feat[0] = normalize(temp, TEMP_MIN, TEMP_MAX);
    feat[1] = normalize(humidity, HUM_MIN, HUM_MAX);

    /* Búsqueda con distancia cuadrática: evita sqrtf() dentro del bucle crítico */
    for (int i = 0; i < K_CLUSTERS; i++) {
        float d_t = feat[0] - clusters[i].centroid[0];
        float d_h = feat[1] - clusters[i].centroid[1];
        float dist_sq = (d_t * d_t) + (d_h * d_h);

        if (dist_sq < result.min_distance) {
            result.min_distance = dist_sq;
            result.cluster_id = clusters[i].id;
            result.cluster_label = clusters[i].label;
        }
    }

    result.min_distance = sqrtf(result.min_distance);
    return result;
}
