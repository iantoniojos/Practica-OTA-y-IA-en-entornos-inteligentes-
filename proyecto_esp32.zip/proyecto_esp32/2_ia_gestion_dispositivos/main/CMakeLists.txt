idf_component_register(SRCS "main.c" "sht31.c" "env_insights.c" "kmeans_regime.c" "sd_logger.c"
                       INCLUDE_DIRS "."
                       REQUIRES driver esp_timer fatfs sdmmc)
