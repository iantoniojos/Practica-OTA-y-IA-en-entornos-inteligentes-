"""!
@file server_ota.py
@brief Servidor HTTPS local para distribuir firmware OTA al ESP32.

Sirve los archivos del directorio actual (por ejemplo firmware_v2.bin)
por HTTPS en el puerto 8070, usando un certificado autofirmado.

Generar el certificado (reemplace la IP por la de su PC):
@code{.sh}
openssl req -x509 -newkey rsa:2048 -keyout server.key -out server.crt -days 365 -nodes \
  -subj "/CN=192.168.1.50" -addext "subjectAltName=IP:192.168.1.50"
@endcode

Archivos requeridos en el mismo directorio: server_ota.py, server.crt,
server.key y firmware_v2.bin.

@author Antonio José Lizcano Rojas
@date 2026
"""

import http.server
import ssl

## Puerto HTTPS del servidor.
PORT = 8070
## Certificado TLS (público).
CERT_FILE = "server.crt"
## Llave privada TLS.
KEY_FILE = "server.key"


class OTARequestHandler(http.server.SimpleHTTPRequestHandler):
    """!
    @brief Manejador HTTP que sirve archivos estáticos con cabecera CORS.
    """

    def end_headers(self):
        """!
        @brief Agrega la cabecera Access-Control-Allow-Origin a cada respuesta.
        """
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()


def main():
    """!
    @brief Crea el servidor, le aplica TLS y lo mantiene en ejecución.

    ESP-IDF exige conexión segura (HTTPS) para esp_https_ota, por eso el
    socket se envuelve con un contexto SSL. Ctrl+C detiene el servidor.
    """
    httpd = http.server.HTTPServer(("", PORT), OTARequestHandler)

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

    print(f"Servidor OTA HTTPS activo en https://0.0.0.0:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.server_close()


if __name__ == "__main__":
    main()
