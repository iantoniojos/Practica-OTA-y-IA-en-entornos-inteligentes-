cmake_minimum_required(VERSION 3.16)

# Componente que provee example_connect() (conexión Wi-Fi vía menuconfig)
set(EXTRA_COMPONENT_DIRS $ENV{IDF_PATH}/examples/common_components/protocol_examples_common)

# Versión del firmware: cámbiela a "2.0.0" al compilar la imagen nueva
set(PROJECT_VER "1.0.0")

include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(ota_esp32)
